<?php
namespace App\Models;

class Alumno extends \Illuminate\Database\Eloquent\Model
{

}