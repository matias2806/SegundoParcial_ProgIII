<?php

namespace App\Models\UTN;

class Inscripcion
{

    static public function saludar()
    {
        echo "Hola Inscripcion";
    }
}
