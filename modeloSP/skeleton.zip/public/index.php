<?

(require __DIR__ . '/../config/bootstrap.php')->run();
// $app->run();










// require __DIR__ . '/../vendor/autoload.php';
// use App\Models\Alumno;
// use App\Models\UTN\Inscripcion;

// echo "Index<br>";

// Alumno::saludar();
// Inscripcion::saludar();